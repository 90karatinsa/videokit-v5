# i18n Coverage Report

Total used keys: 121

| Locale | Coverage | Missing | Unused | Total keys |
| --- | --- | --- | --- | --- |
| de | 100.00% | 0 | 0 | 121 |
| en | 100.00% | 0 | 0 | 121 |
| es | 100.00% | 0 | 0 | 121 |
| tr | 100.00% | 0 | 0 | 121 |

## Orphan used keys

- None

