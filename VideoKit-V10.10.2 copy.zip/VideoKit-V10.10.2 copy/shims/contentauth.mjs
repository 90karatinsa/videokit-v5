// Thin shim so existing imports resolve to the stubbed Content Authenticity module.
export { create } from '../contentauth.mjs';
export { default } from '../contentauth.mjs';
