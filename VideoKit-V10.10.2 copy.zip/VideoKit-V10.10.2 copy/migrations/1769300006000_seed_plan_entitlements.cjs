/* eslint-disable camelcase */

exports.shorthands = undefined;

const PLAN_ROWS = [
  { id: 'free', monthly: 0 },
  { id: 'pro', monthly: 1000 },
  { id: 'pay-as-you-go', monthly: 0 },
  { id: 'trial', monthly: 500 },
];

exports.up = (pgm) => {
  pgm.createTable('plan_entitlements', {
    plan_id: { type: 'text', primaryKey: true },
    monthly_api_calls_total: { type: 'integer', notNull: true },
    endpoint_overrides: { type: 'jsonb', notNull: true, default: pgm.func("'{}'::jsonb") },
    created_at: { type: 'timestamptz', notNull: true, default: pgm.func('now()') },
    updated_at: { type: 'timestamptz', notNull: true, default: pgm.func('now()') },
  }, { ifNotExists: true });

  pgm.sql(`
    DO $$
    BEGIN
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'plan_entitlements'
          AND column_name = 'monthly_api_calls_total'
      ) THEN
        ALTER TABLE public.plan_entitlements
          ADD COLUMN monthly_api_calls_total integer NOT NULL DEFAULT 0;
      END IF;

      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'plan_entitlements'
          AND column_name = 'endpoint_overrides'
      ) THEN
        ALTER TABLE public.plan_entitlements
          ADD COLUMN endpoint_overrides jsonb NOT NULL DEFAULT '{}'::jsonb;
      END IF;

      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'plan_entitlements'
          AND column_name = 'created_at'
      ) THEN
        ALTER TABLE public.plan_entitlements
          ADD COLUMN created_at timestamptz NOT NULL DEFAULT now();
      END IF;

      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'plan_entitlements'
          AND column_name = 'updated_at'
      ) THEN
        ALTER TABLE public.plan_entitlements
          ADD COLUMN updated_at timestamptz NOT NULL DEFAULT now();
      END IF;
    END;
    $$;
  `);

  for (const { id, monthly } of PLAN_ROWS) {
    pgm.sql(`
      INSERT INTO plan_entitlements (plan_id, monthly_api_calls_total, endpoint_overrides, created_at, updated_at)
      VALUES ('${id}', ${monthly}, '{}'::jsonb, now(), now())
      ON CONFLICT (plan_id)
      DO UPDATE SET
        monthly_api_calls_total = EXCLUDED.monthly_api_calls_total,
        endpoint_overrides = EXCLUDED.endpoint_overrides,
        updated_at = now();
    `);
  }
};

exports.down = (pgm) => {
  pgm.sql(`
    DELETE FROM plan_entitlements
    WHERE plan_id IN ('free', 'pro', 'pay-as-you-go', 'trial');
  `);
};
