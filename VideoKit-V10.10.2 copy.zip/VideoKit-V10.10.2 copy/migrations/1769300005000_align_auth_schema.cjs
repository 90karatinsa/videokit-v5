/* eslint-disable camelcase */

exports.shorthands = undefined;

exports.up = (pgm) => {
  pgm.createExtension('pgcrypto', { ifNotExists: true });

  pgm.createTable('tenants', {
    id: {
      type: 'uuid',
      primaryKey: true,
      default: pgm.func('gen_random_uuid()')
    },
    name: { type: 'text', notNull: true },
    plan: { type: 'text', notNull: true, default: 'free' },
    created_at: {
      type: 'timestamp with time zone',
      notNull: true,
      default: pgm.func('current_timestamp')
    },
    updated_at: {
      type: 'timestamp with time zone',
      notNull: true,
      default: pgm.func('current_timestamp')
    }
  }, { ifNotExists: true });

  pgm.sql(`
    DO $$
    BEGIN
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'tenants'
          AND column_name = 'plan'
      ) THEN
        ALTER TABLE public.tenants ADD COLUMN plan text;
        UPDATE public.tenants SET plan = 'free' WHERE plan IS NULL;
        ALTER TABLE public.tenants ALTER COLUMN plan SET DEFAULT 'free';
        ALTER TABLE public.tenants ALTER COLUMN plan SET NOT NULL;
      END IF;

      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'tenants'
          AND column_name = 'created_at'
      ) THEN
        ALTER TABLE public.tenants ADD COLUMN created_at timestamptz;
        UPDATE public.tenants SET created_at = now() WHERE created_at IS NULL;
        ALTER TABLE public.tenants ALTER COLUMN created_at SET NOT NULL;
        ALTER TABLE public.tenants ALTER COLUMN created_at SET DEFAULT now();
      END IF;

      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'tenants'
          AND column_name = 'updated_at'
      ) THEN
        ALTER TABLE public.tenants ADD COLUMN updated_at timestamptz;
      END IF;
      UPDATE public.tenants SET updated_at = now() WHERE updated_at IS NULL;
      ALTER TABLE public.tenants ALTER COLUMN updated_at SET NOT NULL;
      ALTER TABLE public.tenants ALTER COLUMN updated_at SET DEFAULT now();
    END;
    $$;
  `);

  pgm.createTable('users', {
    id: {
      type: 'uuid',
      primaryKey: true,
      default: pgm.func('gen_random_uuid()')
    },
    email: { type: 'text', notNull: true },
    password: { type: 'text', notNull: true },
    password_hash: { type: 'text' },
    full_name: { type: 'text' },
    tenant_id: { type: 'text' },
    role: { type: 'text', notNull: true, default: 'admin' },
    created_at: {
      type: 'timestamp with time zone',
      notNull: true,
      default: pgm.func('current_timestamp')
    },
    updated_at: {
      type: 'timestamp with time zone',
      notNull: true,
      default: pgm.func('current_timestamp')
    }
  }, { ifNotExists: true });

  pgm.sql(`
    DO $$
    BEGIN
      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'users'
          AND column_name = 'tenant_id'
      ) THEN
        ALTER TABLE public.users ADD COLUMN tenant_id text;
      END IF;

      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'users'
          AND column_name = 'role'
      ) THEN
        ALTER TABLE public.users ADD COLUMN role text;
      END IF;

      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'users'
          AND column_name = 'password'
      ) THEN
        ALTER TABLE public.users ADD COLUMN password text;
      END IF;

      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'users'
          AND column_name = 'password_hash'
      ) THEN
        ALTER TABLE public.users ADD COLUMN password_hash text;
      END IF;

      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'users'
          AND column_name = 'full_name'
      ) THEN
        ALTER TABLE public.users ADD COLUMN full_name text;
      END IF;

      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'users'
          AND column_name = 'created_at'
      ) THEN
        ALTER TABLE public.users ADD COLUMN created_at timestamptz DEFAULT now();
      END IF;

      IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'users'
          AND column_name = 'updated_at'
      ) THEN
        ALTER TABLE public.users ADD COLUMN updated_at timestamptz DEFAULT now();
      END IF;
    END;
    $$;
  `);

  pgm.sql(`
    DO $$
    BEGIN
      IF EXISTS (
        SELECT 1 FROM information_schema.tables
        WHERE table_schema = 'public' AND table_name = 'user_tenant_roles'
      ) THEN
        UPDATE public.users u
        SET tenant_id = utr.tenant_id
        FROM public.user_tenant_roles utr
        WHERE u.id = utr.user_id AND u.tenant_id IS NULL;

        IF EXISTS (
          SELECT 1 FROM information_schema.tables
          WHERE table_schema = 'public' AND table_name = 'roles'
        ) THEN
          UPDATE public.users u
          SET role = lower(r.name)
          FROM public.user_tenant_roles utr
          JOIN public.roles r ON r.id = utr.role_id
          WHERE u.id = utr.user_id
            AND (u.role IS NULL OR u.role = '');
        END IF;
      END IF;
    END;
    $$;
  `);

  pgm.sql(`UPDATE public.users SET role = 'admin' WHERE role IS NULL OR role = '';`);
  pgm.sql(`UPDATE public.users SET password = COALESCE(password, password_hash) WHERE password IS NULL AND password_hash IS NOT NULL;`);
  pgm.sql(`UPDATE public.users SET created_at = COALESCE(created_at, now());`);
  pgm.sql(`UPDATE public.users SET updated_at = COALESCE(updated_at, now());`);
  pgm.sql(`UPDATE public.tenants SET created_at = COALESCE(created_at, now());`);
  pgm.sql(`UPDATE public.tenants SET updated_at = COALESCE(updated_at, now());`);

  pgm.sql(`
    ALTER TABLE public.users
      ALTER COLUMN role SET DEFAULT 'admin';
  `);

  pgm.sql(`
    CREATE UNIQUE INDEX IF NOT EXISTS users_email_unique_idx
      ON public.users (lower(email));
  `);
};

exports.down = () => {};
