import express from 'express';
import bcrypt from 'bcrypt';
import crypto from 'crypto';
import { v4 as uuidv4 } from 'uuid';
import promClient from 'prom-client';

import { sendError } from '../http-error.js';

const PASSWORD_RESET_TTL_SECONDS = 60 * 60; // 1 hour
const MIN_PASSWORD_LENGTH = 8;
const DEFAULT_PLAN_ID = process.env.DEFAULT_PLAN_ID?.trim() || 'trial';
const DEFAULT_USER_ROLE = process.env.DEFAULT_USER_ROLE?.trim() || 'admin';
const QUOTA_BLOCK_METRIC = 'quota_block_total';
const ANALYTICS_FAILURE_METRIC = 'analytics_insert_failures_total';

function normaliseEmail(email = '') {
  return email.trim().toLowerCase();
}

function buildResetUrl(req, token) {
  const configuredBase = process.env.FRONTEND_BASE_URL?.trim();
  const baseUrl = configuredBase && configuredBase.startsWith('http')
    ? configuredBase
    : `${req.protocol}://${req.get('host')}`;
  const trimmedBase = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
  return `${trimmedBase}/index.html?resetToken=${token}`;
}

function sanitizeUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    email: user.email,
    fullName: user.fullName,
    roles: user.roles,
    tenantId: user.tenantId,
    createdAt: user.createdAt,
    updatedAt: user.updatedAt,
  };
}

function mapTenantRow(row, fallbackPlan) {
  if (!row) {
    return null;
  }
  const id = row.id ?? row.tenant_id ?? row.tenantid ?? null;
  const plan = row.plan_id ?? row.plan ?? fallbackPlan;
  return {
    id,
    name: row.name,
    plan,
    planId: plan,
    createdAt: row.created_at ?? row.createdat ?? null,
    updatedAt: row.updated_at ?? row.updatedat ?? null,
  };
}


const tableColumnCache = new Map();

async function getTableColumns(client, tableName) {
  const cacheKey = tableName.toLowerCase();
  if (tableColumnCache.has(cacheKey)) {
    return tableColumnCache.get(cacheKey);
  }
  try {
    const result = await client.query(
      'SELECT column_name FROM information_schema.columns WHERE table_schema = $1 AND table_name = $2 ',
      ['public', tableName]
    );
    const columnSet = new Set(result.rows.map((row) => row.column_name));
    tableColumnCache.set(cacheKey, columnSet);
    return columnSet;
  } catch (error) {
    tableColumnCache.set(cacheKey, new Set());
    return new Set();
  }
}

async function sendResetEmail(to, subject, html, req) {
  try {
    const module = await import('../emailService.js');
    if (module?.sendEmail) {
      await module.sendEmail(to, subject, html);
    }
  } catch (error) {
    req?.log?.warn?.({ err: error, to }, '[auth] Password reset email could not be dispatched');
  }
}



async function insertTenant(client, tenantId, companyName, planId) {
  const columns = await getTableColumns(client, 'tenants');
  console.log('[auth.register] columns', Array.from(columns || []));
  if (!columns || columns.size === 0) {
    throw new Error('Tenants table is not accessible.');
  }

  const idColumn = columns.has('id') ? 'id' : (columns.has('tenant_id') ? 'tenant_id' : null);
  if (!idColumn) {
    throw new Error('Tenants table must contain an "id" or "tenant_id" column.');
  }

  const insertColumns = [idColumn];
  const params = [tenantId];

  if (columns.has('name')) {
    insertColumns.push('name');
    params.push(companyName);
  }

  const planColumn = columns.has('plan_id') ? 'plan_id' : (columns.has('plan') ? 'plan' : null);
  console.log('[auth.register] plan column ->', planColumn);
  if (planColumn) {
    insertColumns.push(planColumn);
    params.push(planId);
  } else {
    console.log('[auth.register] plan column missing, skipping planId');
  }

  const placeholders = insertColumns.map((_, idx) => '$' + (idx + 1)).join(', ');

  const returningCandidates = ['id', 'tenant_id', 'name', 'plan_id', 'plan', 'created_at', 'updated_at'];
  const returningColumns = [];
  for (const column of returningCandidates) {
    if (columns.has(column) || column === idColumn) {
      if (!returningColumns.includes(column)) {
        returningColumns.push(column);
      }
    }
  }
  const returningClause = returningColumns.length > 0 ? ' RETURNING ' + returningColumns.join(', ') : '';

  const insertSql = 'INSERT INTO tenants (' + insertColumns.join(', ') + ') VALUES (' + placeholders + ')' + returningClause;
  console.log('[auth.register] insert sql ->', insertSql, 'params ->', params);
  const result = await client.query(insertSql, params);

  const row = (result.rows && result.rows[0]) ? { ...result.rows[0] } : {};
  console.log('[auth.register] insert result row ->', row);
  if (!row[idColumn]) {
    row[idColumn] = tenantId;
  }
  if (!row.id && row[idColumn]) {
    row.id = row[idColumn];
  }
  if (!row.tenant_id && columns.has('tenant_id') && row[idColumn]) {
    row.tenant_id = row[idColumn];
  }

  if (planId) {
    if (planColumn && row[planColumn] == null) {
      row[planColumn] = planId;
    }
    if (row.plan == null) {
      row.plan = planColumn === 'plan_id' ? planId : (row.plan ?? planId);
    }
    if (row.plan_id == null && planColumn === 'plan_id') {
      row.plan_id = planId;
    }
  }

  console.log('[auth.register] normalized tenant row ->', row);
  return row;
}


async function insertUser(client, { email, passwordHash, fullName, tenantId, role }) {
  try {
    const result = await client.query(
      'INSERT INTO users (email, password, full_name, tenant_id, role) VALUES ($1, $2, $3, $4, $5) RETURNING id, email, role, tenant_id',
      [email, passwordHash, fullName, tenantId, role],
    );
    return result.rows[0];
  } catch (error) {
    if (error.code !== '42703') {
      throw error;
    }
  }
  const fallback = await client.query(
    'INSERT INTO users (email, password_hash, full_name, tenant_id, role) VALUES ($1, $2, $3, $4, $5) RETURNING id, email, role, tenant_id',
    [email, passwordHash, fullName, tenantId, role],
  );
  return fallback.rows[0];
}

function resolvePasswordColumn(row) {
  return row?.password ?? row?.password_hash ?? null;
}

async function updateUserPassword(dbPool, userId, passwordHash) {
  const statements = [
    {
      sql: 'UPDATE users SET password = $1, updated_at = NOW() WHERE id = $2',
      params: [passwordHash, userId],
    },
    {
      sql: 'UPDATE users SET password_hash = $1, updated_at = NOW() WHERE id = $2',
      params: [passwordHash, userId],
    },
  ];

  for (const statement of statements) {
    try {
      const result = await dbPool.query(statement.sql, statement.params);
      if (result.rowCount > 0) {
        return true;
      }
    } catch (error) {
      if (error.code !== '42703') {
        throw error;
      }
    }
  }

  return false;
}

export default function createAuthRouter({ dbPool, redis, config, auth }) {
  if (!dbPool || !redis || !config || !auth) {
    throw new Error('createAuthRouter requires database, redis, config and auth helpers.');
  }

  const router = express.Router();
  const { protect, issueSession, destroySession, loadUserContext } = auth;

  router.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok' });
  });

  router.post('/register', async (req, res) => {
    const { companyName, email, password } = req.body ?? {};
    const trimmedCompany = companyName?.trim();
    const normalisedEmail = normaliseEmail(email);

    if (!trimmedCompany || !normalisedEmail || !password || password.length < MIN_PASSWORD_LENGTH) {
      return sendError(res, req, 400, 'REGISTRATION_INVALID', 'Valid company name, email, and password (>= 8 chars) are required.');
    }

    const client = await dbPool.connect();
    try {
      await client.query('BEGIN');

      const existing = await client.query('SELECT id FROM users WHERE email = $1', [normalisedEmail]);
      if (existing.rowCount > 0) {
        await client.query('ROLLBACK');
        return sendError(res, req, 409, 'REGISTRATION_CONFLICT', 'An account with this email already exists.');
      }

      const tenantId = uuidv4();
      const planId = config?.defaults?.defaultPlanId || DEFAULT_PLAN_ID;
      const tenantRow = await insertTenant(client, tenantId, trimmedCompany, planId);
      const tenant = mapTenantRow(tenantRow, planId);

      const passwordHash = await bcrypt.hash(password, 12);
      const userRow = await insertUser(client, {
        email: normalisedEmail,
        passwordHash,
        fullName: trimmedCompany,
        tenantId,
        role: DEFAULT_USER_ROLE,
      });

      await client.query('COMMIT');

      try {
        await redis.hset(`tenant:${tenantId}`, {
          id: tenantId,
          name: tenant?.name ?? trimmedCompany,
          plan: tenant?.plan ?? planId,
        });
      } catch (error) {
        req.log?.warn?.({ err: error, tenantId }, '[auth] Failed to prime Redis tenant cache after registration');
      }

      req.log?.info?.({ tenantId, userId: userRow.id }, '[auth] Registration successful');
      return res.status(201).json({
        message: 'Registration successful. Please sign in to continue.',
      });
    } catch (error) {
      await client.query('ROLLBACK');
      req.log?.error?.({ err: error }, '[auth] Registration failed');
      if (error.code === '23505') {
        return sendError(res, req, 409, 'REGISTRATION_CONFLICT', 'An account with this email already exists.');
      }
      return sendError(res, req, 500, 'REGISTRATION_FAILED', 'Registration failed due to a server error.');
    } finally {
      client.release();
    }
  });

  router.post('/login', async (req, res) => {
    const { email, password } = req.body ?? {};
    if (!email || !password) {
      return sendError(res, req, 400, 'LOGIN_INVALID', 'Email and password are required.');
    }

    const normalisedEmail = normaliseEmail(email);

    try {
      const result = await dbPool.query(
        'SELECT id, email, password, password_hash, role, tenant_id FROM users WHERE email = $1',
        [normalisedEmail],
      );

      if (result.rowCount === 0) {
        return sendError(res, req, 401, 'LOGIN_FAILED', 'Invalid credentials.');
      }

      const user = result.rows[0];
      const storedHash = resolvePasswordColumn(user);
      if (!storedHash) {
        req.log?.error?.({ userId: user.id }, '[auth] No password hash found for user');
        return sendError(res, req, 500, 'LOGIN_MISCONFIGURED', 'Authentication data is missing for this account.');
      }

      const passwordMatch = await bcrypt.compare(password, storedHash);
      if (!passwordMatch) {
        return sendError(res, req, 401, 'LOGIN_FAILED', 'Invalid credentials.');
      }

      issueSession(req, res, {
        userId: user.id,
        tenantId: user.tenant_id,
        roles: [user.role ?? DEFAULT_USER_ROLE],
      });

      return res.status(200).json({ message: 'Login successful.' });
    } catch (error) {
      req.log?.error?.({ err: error }, '[auth] Login failed');
      return sendError(res, req, 500, 'LOGIN_ERROR', 'Login failed due to a server error.');
    }
  });

  router.get('/me', protect, (req, res) => {
    if (!req.user) {
      return sendError(res, req, 401, 'AUTH_REQUIRED', 'Authentication required.');
    }

    const user = sanitizeUser(req.user);
    const tenant = req.tenant ? mapTenantRow(req.tenant, DEFAULT_PLAN_ID) : null;

    return res.status(200).json({ user, tenant });
  });

  router.post('/logout', (req, res) => {
    destroySession(req, res);
    res.status(204).send();
  });

  router.post('/forgot-password', async (req, res) => {
    const { email } = req.body ?? {};
    if (!email) {
      return sendError(res, req, 400, 'FORGOT_PASSWORD_INVALID', 'Email is required.');
    }

    const normalisedEmail = normaliseEmail(email);

    try {
      const userResult = await dbPool.query('SELECT id FROM users WHERE email = $1', [normalisedEmail]);

      if (userResult.rowCount === 0) {
        return res.status(200).json({ message: 'If this email exists, a reset link has been sent.' });
      }

      const userId = userResult.rows[0].id;
      const resetToken = crypto.randomBytes(32).toString('hex');
      await redis.set(`password_reset:${resetToken}`, JSON.stringify({ userId }), 'EX', PASSWORD_RESET_TTL_SECONDS);

      const resetUrl = buildResetUrl(req, resetToken);
      const emailBody = `
        <p>We received a request to reset your VideoKit password.</p>
        <p><a href="${resetUrl}">Click here</a> to set a new password. This link will expire in one hour.</p>
        <p>If you did not request this change, you can safely ignore this message.</p>
      `;

      await sendResetEmail(normalisedEmail, 'Reset your VideoKit password', emailBody, req);

      return res.status(200).json({ message: 'If this email exists, a reset link has been sent.' });
    } catch (error) {
      req.log?.error?.({ err: error }, '[auth] Forgot password failed');
      return sendError(res, req, 500, 'FORGOT_PASSWORD_FAILED', 'Unable to initiate password reset.');
    }
  });

  router.post('/reset-password', async (req, res) => {
    const { token, password } = req.body ?? {};

    if (!token || !password) {
      return sendError(res, req, 400, 'RESET_PASSWORD_INVALID', 'Token and password are required.');
    }

    if (password.length < MIN_PASSWORD_LENGTH) {
      return sendError(res, req, 400, 'RESET_PASSWORD_WEAK', 'Password must be at least 8 characters.');
    }

    try {
      const payload = await redis.get(`password_reset:${token}`);
      if (!payload) {
        return sendError(res, req, 400, 'RESET_PASSWORD_TOKEN_INVALID', 'Reset token is invalid or has expired.');
      }

      const { userId } = JSON.parse(payload);
      const passwordHash = await bcrypt.hash(password, 12);
      const updated = await updateUserPassword(dbPool, userId, passwordHash);
      await redis.del(`password_reset:${token}`);

      if (!updated) {
        req.log?.error?.({ userId }, '[auth] Failed to update password');
        return sendError(res, req, 500, 'RESET_PASSWORD_FAILED', 'Password could not be updated.');
      }

      const context = await loadUserContext(userId);
      if (context?.user?.id) {
        issueSession(req, res, {
          userId: context.user.id,
          tenantId: context.user.tenantId,
          roles: context.user.roles,
        });
      }

      return res.status(200).json({ message: 'Password updated successfully.' });
    } catch (error) {
      req.log?.error?.({ err: error }, '[auth] Reset password failed');
      return sendError(res, req, 500, 'RESET_PASSWORD_ERROR', 'Password reset failed due to a server error.');
    }
  });

  router.post('/simulate-quota', (req, res) => {
    const counter = promClient.register.getSingleMetric(QUOTA_BLOCK_METRIC);
    const tenant = req.body?.tenant || 'demo';
    const endpoint = req.body?.endpoint || '/simulate';
    if (counter?.inc) {
      counter.inc({ tenant, endpoint });
    }
    res.status(200).json({ ok: true, tenant, endpoint });
  });

  router.post('/simulate-analytics-failure', (req, res) => {
    const counter = promClient.register.getSingleMetric(ANALYTICS_FAILURE_METRIC);
    if (counter?.inc) {
      counter.inc();
    }
    res.status(200).json({ ok: true });
  });

  return router;
}
